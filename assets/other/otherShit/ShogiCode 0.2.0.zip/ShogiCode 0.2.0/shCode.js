/**
 *
 *
 * @version 0.2.0
 * @author Surafel Tewabe and Samuel Birhanu
 * @copyright Chebes Group
 * @license MIT
 */


function shogi(str) {
  let encStr;
  let encStrArr = [];
  let strArr = [];
  str = str.toLocaleLowerCase();
  strArr = str.split("");
  for (let index = 0; index < strArr.length; index++) {
      let char;
      switch (strArr[index]) {
          case "a":
              char = "0000";
              break;
          case "b":
              char = "0001";
              break;
          case "c":
              char = "0002"
              break;
          case "d":
              char = "0003";
              break;
          case "e":
              char = "0010";
              break;
          case "f":
              char = "0011";
              break;
          case "g":
              char = "0012";
              break;
          case "h":
              char = "0013"
              break;
          case "i":
              char = "0020";
              break;
          case "j":
              char = "0021"
              break;
          case "k":
              char = "0022";
              break;
          case "l":
              char = "0023"
              break;
          case "m":
              char = "0030"
              break;
          case "n":
              char = "0031";
              break;
          case "o":
              char = "0032"
              break;
          case "p":
              char = "0033"
              break;
          case "r":
              char = "0040";
              break;
          case "s":
              char = "0041"
              break;
          case "t":
              char = "0042";
              break;
          case "u":
              char = "0043"
              break;
          case "v":
              char = "0050";
              break
          case "w":
              char = "0051"
              break;
          case "x":
              char = "0052";
              break
          case "y":
              char = "0053";
              break;
          case "z":
              char = "0060";
              break;
          case "0":
              char = "1100"
              break;
          case "1":
              char = "1101"
              break
          case "2":
              char = "1102"
              break;
          case "3":
              char = "1103"
              break;
          case "4":
              char = "1110"
              break;
          case "5":
              char = "1111"
              break;
          case "6":
              char = "1112"
              break;
          case "7":
              char = "1113"
              break;
          case "8":
              char = "1120"
              break;
          case "9":
              char = "1121"
              break;
          case " ":
              char = "1009"
              break;     
          default:
              char = "1999";
              break;
      }
      encStrArr.push(char);
  }
  encStr = encStrArr.join(" ");
  return encStr;
}

function shogi4(str) {
  let encstrArr = [];
  let char, encstr;
  for (i = 0; i < str.length; i++) {
    char = String(str.charCodeAt(i) % 4);
    switch (char) {
      case "0":
        char = ",";
        break;
      case "1":
        char = "l";
        break;
      case "2":
        char = "p";
        break;
      case "3":
        char = "-";
        break;
      default:
        char = char;
        break;
    }
    encstrArr.push(char);
    encstr = encstrArr.join("");
  }
  return encstr;
}
function shogi17(str) {
  let encstrArr = [];
  let char, encstr;
  for (i = 0; i < str.length; i++) {
    char = String(str.charCodeAt(i) % 17);
    switch (char) {
      case "10":
        char = "a";
        break;
      case "11":
        char = "b";
        break;
      case "12":
        char = "c";
        break;
      case "13":
        char = "d";
        break;
      case "14":
        char = "e";
        break
      case "15":
        char = "f";
        break;
      case "16":
        char = "g";
        break;
      default:
        char = char;
        break;
    }
    encstrArr.push(char);
    encstr = encstrArr.join("");
  }
  return encstr;
}
